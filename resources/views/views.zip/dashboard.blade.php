@extends('layouts.main')

@section('container')

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
        <div class="content-header">
          <div class="container-fluid">
            <div class="row mb-2">
              <div class="col-sm-6">
                <h1 class="m-0">Dashboard</h1>
              </div><!-- /.col -->
              <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                  <li class="breadcrumb-item"><a href="#">Home</a></li>
                  <li class="breadcrumb-item active">Dashboard</li>
                </ol>
              </div><!-- /.col -->
            </div><!-- /.row -->
          </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->
    
        <!-- Main content -->
        <section class="content">
          <div class="container-fluid">

            <!-- Info boxes -->
            <div class="row"> <!-- /.row -->
              @if (count($dashboards) > 0)
                @foreach ($dashboards as $dt )
                @endforeach 
              @endif
              

              <div class="col-12 col-sm-6 col-md-3">
                <div class="info-box mb-3">
                  <span class="info-box-icon bg-success elevation-1"><i class="fas fa-water"></i></span>
    
                  <div class="info-box-content">
                    <span class="info-box-text"> Value 1</span>
                    <h2 class="info-box-number">
                      @if (count($dashboards) > 0)
                        <span id="value1"></span>  
                        <small>Val </small>
                      @else
                        No Data
                      @endif
                    </h2>
                  </div>
                </div>
              </div>

              <div class="col-12 col-sm-6 col-md-3">
                <div class="info-box mb-3">
                  <span class="info-box-icon bg-success elevation-1"><i class="fas fa-temperature-low"></i></span>
    
                  <div class="info-box-content">
                    <span class="info-box-text">Value 2</span>
                    <h2 class="info-box-number">
                      @if (count($dashboards) > 0)
                        <span id="value2"></span>  
                        <small>Val</small>
                      @else
                        No Data
                      @endif
                    </h2>
                  </div>
                </div>
              </div>
              <!-- fix for small devices only -->
              <div class="clearfix hidden-md-up"></div>
              <div class="col-12 col-sm-6 col-md-3">
                <div class="info-box mb-3">
                  <span class="info-box-icon bg-success elevation-1"><i class="fas fa-water"></i></span>
    
                  <div class="info-box-content">
                    <span class="info-box-text"> Value 3</span>
                    <h2 class="info-box-number">
                      @if (count($dashboards) > 0)
                        <span id="value3"></span>   
                        <small>Val </small>
                      @else
                        No Data
                      @endif
                    </h2>
                  </div>
                </div>
              </div>

              <div class="col-12 col-sm-6 col-md-3">
                <div class="info-box mb-3">
                  <span class="info-box-icon bg-success elevation-1"><i class="fas fa-temperature-low"></i></span>
    
                  <div class="info-box-content">
                    <span class="info-box-text">Value 4</span>
                    <h2 class="info-box-number">
                      @if (count($dashboards) > 0)
                        <span id="value4"></span>  
                        <small>Val</small>
                      @else
                        No Data
                      @endif
                    </h2>
                  </div>
                </div>
              </div>
            </div> <!-- /.row -->

            <div class="row">
              <div class="col-md-12">
                <div class="card">
                  @if (session()->has('mqtt-notif1'))
                      <br>
                      <div class="alert alert-success alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        <h5><i class="icon fas fa-check"></i> Alert!</h5>
                        {{ session('notif1') }}
                      </div>
                  @endif
                  <br>
                  <table class="text-center">
                    <tr>
                      <td>
                        <form action="{{ route('publish-mqtt') }}" method="POST">
                            @csrf
                            <button type="submit" class="btn btn-block btn-success btn-sm">Publish MQTT Message</button>
                        </form>
                      </td>
                      <td>
                        <form action="{{ route('publish-mqtt') }}" method="POST">
                            @csrf
                            <button type="submit"  class="btn btn-block btn-success btn-sm">Publish MQTT Message</button>
                        </form>
                      </td>
                      <td>
                        <form action="{{ route('publish-mqtt') }}" method="POST">
                            @csrf
                            <button type="submit"  class="btn btn-block btn-success btn-sm">Publish MQTT Message</button>
                        </form>
                      </td>
                      <td>
                        <form action="{{ route('publish-mqtt') }}" method="POST">
                            @csrf
                            <button type="submit"  class="btn btn-block btn-success btn-sm">Publish MQTT Message</button>
                        </form>
                      </td>
                    </tr>
                  </table>
                  <br>
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-md-12">
                <div class="card">
                  @if (session()->has('mqtt-notif2'))
                      <br>
                      <div class="alert alert-success alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        <h5><i class="icon fas fa-check"></i> Alert!</h5>
                        {{ session('mqtt-notif2') }}
                      </div>
                  @endif
                  <br>
                  <form action="{{ route('publish-mqttCustom') }}" method="POST">
                    @csrf
                    <div class="card-body">
                      <div class="form-group">
                        <label for="exampleInputEmail1">Mqtt</label>
                        <input  type="text" id="custom-data" name="custom_data" class="form-control" placeholder="MQTT Message to topi idrus/septi">
                      </div>
                    </div>
                    <div class="card-footer">
                      <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
    
            <div class="row">
              <div class="col-md-12">
                <div class="card">
                  <div class="card-header">
                    <h5 class="card-title">Monthly Recap Report</h5>
    
                    <div class="card-tools">
                      <button type="button" class="btn btn-tool" data-card-widget="collapse">
                        <i class="fas fa-minus"></i>
                      </button>
                      <button type="button" class="btn btn-tool" data-card-widget="remove">
                        <i class="fas fa-times"></i>
                      </button>
                    </div>
                  </div>
                  
                  <div class="card-footer">
                    <div class="row">
                      <div class="col-sm-3 col-6">
                        <div class="description-block border-right">
                          <span class="description-percentage text-success"><i class="fas fa-caret-up"></i> 17%</span>
                          <h5 class="description-header">$35,210.43</h5>
                          <span class="description-text">TOTAL REVENUE</span>
                        </div>
                        <!-- /.description-block -->
                      </div>
                      <!-- /.col -->
                      <div class="col-sm-3 col-6">
                        <div class="description-block border-right">
                          <span class="description-percentage text-warning"><i class="fas fa-caret-left"></i> 0%</span>
                          <h5 class="description-header">$10,390.90</h5>
                          <span class="description-text">TOTAL COST</span>
                        </div>
                        <!-- /.description-block -->
                      </div>
                      <!-- /.col -->
                      <div class="col-sm-3 col-6">
                        <div class="description-block border-right">
                          <span class="description-percentage text-success"><i class="fas fa-caret-up"></i> 20%</span>
                          <h5 class="description-header">$24,813.53</h5>
                          <span class="description-text">TOTAL PROFIT</span>
                        </div>
                        <!-- /.description-block -->
                      </div>
                      <!-- /.col -->
                      <div class="col-sm-3 col-6">
                        <div class="description-block">
                          <span class="description-percentage text-danger"><i class="fas fa-caret-down"></i> 18%</span>
                          <h5 class="description-header">1200</h5>
                          <span class="description-text">GOAL COMPLETIONS</span>
                        </div>
                        <!-- /.description-block -->
                      </div>
                    </div>
                    <!-- /.row -->
                  </div>
                  <!-- /.card-footer -->
                </div>
                <!-- /.card -->
              </div>
              <!-- /.col -->
            </div>
            <!-- /.row -->
          </div><!--/. container-fluid -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <!-- /.content-wrapper -->
    <script type="text/javascript">
      $(document).ready(function() {
        setInterval(function() {
          $("#value1").load("dashboard/value1");
          $("#value2").load("dashboard/value2");
          $("#value3").load("dashboard/value3");
          $("#value4").load("dashboard/value4");
        }, 1000);
      })
    </script>
@endsection